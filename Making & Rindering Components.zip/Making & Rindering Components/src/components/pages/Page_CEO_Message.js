function Page_CEO_Message(){
    return(

        <div className='page_ceo_message'>
            <div className='page_message'>
                <h3>Message</h3>

            </div>
            <div className='page_ceo'>
            <h3>CEO</h3>

            </div>

        </div>
    )
}

export default Page_CEO_Message
