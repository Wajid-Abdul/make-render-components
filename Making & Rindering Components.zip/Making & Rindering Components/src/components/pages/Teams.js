function Teams(){
    return(
        <div className='Teams'>
            <div className='team1'>
            <h3>Team1</h3>

            </div>
            <div className='team2'>
            <h3>Team2</h3>

            </div>
            <div className='team3'>
            <h3>Team3</h3>

            </div> 

        </div>
    )
}

export default Teams