function Header(){
    return(
        <div className ='heading'>
            <h3>Header</h3>
        </div>
    )
}

export default Header