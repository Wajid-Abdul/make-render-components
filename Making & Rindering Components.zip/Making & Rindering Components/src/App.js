
// Importing the components
import logo from './logo.svg';
import './App.css';
import Header from './components/Header'
import Page_CEO_Message from './components/pages/Page_CEO_Message'
import Intro from './components/pages/Page_Intro'
import Teams from './components/pages/Teams'
import Footer from './components/Footer'




// Rendering the compoents
function App() {
  return (
    <div className="App">
      <Header />
      <Page_CEO_Message />
      <Intro />
      <Teams />
      <Footer />
    </div>
  );
}

export default App;
